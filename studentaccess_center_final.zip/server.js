const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.redirect('/login');
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', (req, res) => {
    const { studentID, password } = req.body;
    res.redirect('/portal');
});

app.get('/portal', (req, res) => {
    res.render('index');
});

app.post('/go', (req, res) => {
    let target = req.body.url;
    if (!/^https?:\/\//i.test(target)) {
        target = 'https://' + target;
    }
    res.redirect(`/proxy/${Buffer.from(target).toString('base64')}`);
});

app.use('/proxy/:encodedUrl', (req, res, next) => {
    const decodedUrl = Buffer.from(req.params.encodedUrl, 'base64').toString('utf-8');

    return createProxyMiddleware({
        target: decodedUrl,
        changeOrigin: true,
        secure: false,
        pathRewrite: {
            [`^/proxy/${req.params.encodedUrl}`]: '',
        },
        onProxyReq(proxyReq, req, res) {
            proxyReq.setHeader('Referer', decodedUrl);
        },
    })(req, res, next);
});

app.listen(PORT, () => {
    console.log(`Student Access Center running on port ${PORT}`);
});